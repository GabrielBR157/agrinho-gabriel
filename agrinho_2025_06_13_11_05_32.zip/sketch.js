let player;
let cityStartX;
let fruits = [], boxes = [], sticks = [];
let carrying = { fruits: 0, boxes: 0, sticks: 0 };
let score = 0;
let timer = 60; // segundos
let gameOver = false;

function setup() {
  createCanvas(800, 400);
  cityStartX = width / 2;
  player = { x: 50, y: height / 2, size: 40, speed: 4 };
  
  for (let i = 0; i < 10; i++) fruits.push({ x: random(20, cityStartX - 40), y: random(20, height - 40), size: 20, collected: false });
  for (let i = 0; i < 8; i++) boxes.push({ x: random(cityStartX + 20, width - 40), y: random(20, height - 40), size: 25, collected: false });
  sticks.push({ x: random(cityStartX + 20, width - 40), y: random(20, height - 40), size: 30, collected: false });
  
  setInterval(() => { if (!gameOver) timer--; if (timer <= 0) gameOver = true; }, 1000);
}

function draw() {
  background(200);
  if (gameOver) {
    textAlign(CENTER, CENTER);
    textSize(48);
    fill(0);
    text("Game Over!\nScore: " + score, width/2, height/2);
    return;
  }
  
  // Áreas
  noStroke();
  fill(100, 200, 100); rect(0, 0, cityStartX, height);    // campo verde
  fill(150); rect(cityStartX, 0, width - cityStartX, height); // cidade cinza
  
  // Prédios cidade
  fill(80);
  for (let i = cityStartX + 20; i < width - 20; i += 70)
    rect(i, height - 150, 50, 150);
  
  // Desenhar e coletar frutas (campo)
  fill(255, 165, 0);
  fruits.forEach(f => {
    if (!f.collected) ellipse(f.x, f.y, f.size);
  });
  
  // Desenhar e coletar caixas (cidade)
  fill(0, 0, 255);
  boxes.forEach(b => {
    if (!b.collected) rect(b.x, b.y, b.size, b.size);
  });
  
  // Desenhar e coletar bastão (cidade)
  fill(139, 69, 19);
  sticks.forEach(s => {
    if (!s.collected) rect(s.x, s.y, s.size, s.size/4);
  });
  
  // Movimento
  if (keyIsDown(LEFT_ARROW)) player.x = max(0, player.x - player.speed);
  if (keyIsDown(RIGHT_ARROW)) player.x = min(width - player.size, player.x + player.speed);
  if (keyIsDown(UP_ARROW)) player.y = max(0, player.y - player.speed);
  if (keyIsDown(DOWN_ARROW)) player.y = min(height - player.size, player.y + player.speed);
  
  let inCity = player.x > cityStartX;
  
  // Coleta simplificada
  function tryCollect(items, type) {
    items.forEach(item => {
      if (!item.collected && dist(player.x + player.size/2, player.y + player.size/2, item.x + (item.size/2 || 0), item.y + (item.size/2 || 0)) < player.size/2 + item.size/2) {
        item.collected = true;
        carrying[type]++;
      }
    });
  }
  
  if (!inCity) {
    tryCollect(fruits, "fruits");
    // Entregar caixas e bastão no campo
    if (carrying.boxes > 0) { score += carrying.boxes * 20; carrying.boxes = 0; }
    if (carrying.sticks > 0) { score += carrying.sticks * 30; carrying.sticks = 0; }
  } else {
    tryCollect(boxes, "boxes");
    tryCollect(sticks, "sticks");
    // Entregar frutas na cidade
    if (carrying.fruits > 0) { score += carrying.fruits * 10; carrying.fruits = 0; }
  }
  
  // Desenhar jogador
  fill(inCity ? [0, 0, 255] : [255, 0, 0]);
  rect(player.x, player.y, player.size, player.size);
  
  // Texto HUD
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text(`Tempo: ${timer}s`, 10, 20);
  text(`Score: ${score}`, 10, 40);
  text(`Frutas: ${carrying.fruits}`, 10, 60);
  text(`Caixas: ${carrying.boxes}`, 10, 80);
  text(`Bastão: ${carrying.sticks}`, 10, 100);
  text("Colete frutas no campo e caixas+bastão na cidade.", 10, height - 20);
}
